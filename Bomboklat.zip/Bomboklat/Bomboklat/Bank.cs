﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomboklat
{
    internal class Bank
    {
        private string bankName;
        private string bankDescription;
        private int bankHotline;
        private bool isInPoland;

        public Bank(string bankName, string bankDescription, int bankHotline, bool isInPoland)
        {
            this.bankName = bankName;
            this.bankDescription = bankDescription;
            this.bankHotline = bankHotline;
            this.isInPoland = isInPoland;
        }

        public string getBankName()
        {
            return this.bankName;
        }
        public string getBankDescription()
        {
            return this.bankDescription;
        }
        public int getBankHotline()
        {
            return this.bankHotline;
        }
        public bool getIsInPoland()
        {
            return this.isInPoland;
        }

        public void myMethodShowBank()
        {
            Console.WriteLine(this.getBankName() + " " + this.getBankDescription() + " " + this.getBankHotline() + " " + this.getIsInPoland());
        }
    }
}
