﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Bomboklat
{
    internal class Person
    {
        private string name;
        private string surname;
        private int age;
        private bool isMale;

        public Person(string name, string surname, int age, bool isMale)
        {
            this.name = name;
            this.surname = surname;
            this.age = age;
            this.isMale = isMale;
        }

        public string getName()
        {
            return this.name;
        }
        public string getSurname()
        {
            return this.surname;
        }
        public int getAge()
        {
            return this.age;
        }
        public bool getIsMale()
        {
            return this.isMale;
        }

        public void myMethodShowPerson()
        {
            Console.WriteLine(this.getName() + " " + this.getSurname() + " " + this.getAge() + " " + this.getIsMale());
        }


    }

}
