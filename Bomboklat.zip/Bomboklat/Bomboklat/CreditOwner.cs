﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomboklat
{
    internal class CreditOwner
    {
        private string COname;
        private string COsurname;
        private int COage;
        private bool creditWorthiness;

        public CreditOwner(string COname, string COsurname, int COage, bool creditWorthiness)
        {
            this.COname = COname;
            this.COsurname = COsurname;
            this.COage = COage;
            this.creditWorthiness = creditWorthiness;
        }

        public string getCOName()
        {
            return this.COname;
        }
        public string getCOSurname()
        {
            return this.COsurname;
        }
        public int getCOAge()
        {
            return this.COage;
        }
        public bool getCreditWorthiness()
        {
            return this.creditWorthiness;
        }

        public void myMethodShowCreditOwner()
        {
            Console.WriteLine(this.getCOName() + " " + this.getCOSurname() + " " + this.getCOAge() + " " + this.getCreditWorthiness());
        }


    }
}
