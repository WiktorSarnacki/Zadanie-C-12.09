﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomboklat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Bank milenium = new Bank("milenium", "najleprzy bank na świecie", 573323912, true);

            Person kaper = new Person("Kacper", "Superson", 16, true);

            CreditOwner COmilunio = new CreditOwner("Miłosz", "Ratkiewicz", 16, false);

            milenium.myMethodShowBank();

            kaper.myMethodShowPerson();

            COmilunio.myMethodShowCreditOwner();
            Console.ReadKey();
        }
    }
}
